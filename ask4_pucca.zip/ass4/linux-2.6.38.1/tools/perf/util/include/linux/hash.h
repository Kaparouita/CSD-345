#include "../../../../include/linux/hash.h"

#ifndef PERF_HASH_H
#define PERF_HASH_H
#endif
